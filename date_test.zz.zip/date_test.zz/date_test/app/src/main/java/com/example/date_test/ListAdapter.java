package com.example.date_test;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Objects;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ListViewHolder> {

    ArrayList<Sensor> sensorArrayList;
    ArrayList<String> date_list;
    Context context;
    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("hh시 mm분");

    public ListAdapter(ArrayList<Sensor> sensorArrayList, ArrayList<String> date_list, Context context) {
        this.sensorArrayList = sensorArrayList;
        this.date_list = date_list;
        this.context = context;
    }

    @NonNull

    @Override
    public ListAdapter.ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.list,parent,false);
        return new ListViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ListAdapter.ListViewHolder holder, int position) {
        String time_text = null;
        int max = 0;
        int progress;

        long start_time = sensorArrayList.get(position).getStart();
        long stop_time = sensorArrayList.get(position).getStop();

        if(date_list.get(position).isEmpty()){
            holder.tv_date.setVisibility(View.GONE) ;
        }else{
            holder.tv_date.setText(date_list.get(position));
        }

        //String time_date = simpleDateFormat.format(start_time);
        String time_date = sensorArrayList.get(position).getTime_str();

        progress = (int) (stop_time - start_time);
        String mode_text = sensorArrayList.get(position).getMode();
        Log.d("TAG",mode_text);

        switch (mode_text){
            case "양치하기":
                time_text = "3min";
                max = 180;
                if(progress >= max){
                    holder.profile.setImageDrawable(context.getResources().getDrawable(R.drawable.wash2_complete));
                }else {
                    holder.profile.setImageDrawable(context.getResources().getDrawable(R.drawable.wash2));
                }
                Log.d("TAG","양치 modetext면 3분");
                break;

            case "세수하기":
                time_text = "1min";
                max = 60;
                Log.d("TAG","세수 modetext면 1분");
                if(progress >= max){
                    holder.profile.setImageDrawable(context.getResources().getDrawable(R.drawable.wash4_complete));
                }else {
                    holder.profile.setImageDrawable(context.getResources().getDrawable(R.drawable.wash4));
                }
                break;

            case "손씻기":
                time_text = "30s";
                max = 30;
                Log.d("TAG","손씻기 modetext면 30초");
                if(progress >= max){
                    holder.profile.setImageDrawable(context.getResources().getDrawable(R.drawable.wash5_complete));
                }else {
                    holder.profile.setImageDrawable(context.getResources().getDrawable(R.drawable.wash5));
                }
                break;
        }

        holder.tv_datetime.setText(time_date);
        holder.mode.setText(mode_text);
        holder.time.setText(time_text);
        holder.progressBar.setMax(max);
        if(stop_time ==0){
            holder.progressBar.setProgress(0);
        }else{
            holder.progressBar.setProgress(progress);
        }

    }

    @Override
    public int getItemCount() {
        if (sensorArrayList == null) {
            return 0;
        }

        return sensorArrayList.size();
    }


    public class ListViewHolder extends RecyclerView.ViewHolder{
        TextView mode,time;
        ImageView profile;
        TextView tv_date,tv_datetime;
        ProgressBar progressBar;

        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            this.mode = itemView.findViewById(R.id.tv_mode);
            this.time = itemView.findViewById(R.id.tv_time);
            this.tv_date = itemView.findViewById(R.id.tv_date);
            this.progressBar = itemView.findViewById(R.id.progressBar);
            this.profile = itemView.findViewById(R.id.iv_profile);
            this.tv_datetime = itemView.findViewById(R.id.tv_datetime);
        }
    }
}
