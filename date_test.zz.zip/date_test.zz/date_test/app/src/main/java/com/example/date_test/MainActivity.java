package com.example.date_test;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.messaging.FirebaseMessaging;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import static java.sql.DriverManager.println;

public class MainActivity extends AppCompatActivity {
    LinearLayoutManager manager;
    RecyclerView recyclerView;
    ArrayList<Sensor> sensorArrayList;
    ArrayList<String> date_list;
    ArrayList<String> dates;
    ListAdapter listAdapter;
    FirebaseFirestore db;
    ProgressDialog progressDialog;
    TextView date;
    SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-MM-dd");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false); //뒤로가기 버튼을 눌러서 종료 불가
        progressDialog.setMessage("데이터 로딩중...");
        progressDialog.show();

        date = findViewById(R.id.tv_date);

        db = FirebaseFirestore.getInstance();
        sensorArrayList = new ArrayList<Sensor>();
        date_list = new ArrayList<>();
        dates = new ArrayList<>();
        listAdapter = new ListAdapter(sensorArrayList,dates,MainActivity.this);

        FirebaseMessaging.getInstance().getToken() //fcm 이용에 필요한 앱 토큰 가져오기
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Log.w("token_error", "Fetching FCM registration token failed", task.getException());
                            return;
                        }
                        String token = task.getResult();
                        Log.d("token", "token : "+token);
                    }
                });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        manager = new LinearLayoutManager(this); //recyclerView 리스트를 역순으로 출력
        //recyclerView.scrollToPosition(sensorArrayList.size()-1);
        //manager.scrollToPositionWithOffset(listAdapter.getItemCount(), 0);
        recyclerView.setLayoutManager(manager);
        //recyclerView.scrollToPosition(listAdapter.getItemCount() - 1);

        sensorArrayList.clear();
        date_list.clear();
        dates.clear();

        EventChangeListener_Sensor();

        recyclerView.setAdapter(listAdapter);
        

    }


    private void EventChangeListener_Sensor() {  //데이터베이스에 저장된 document들을 시작시간 timestamp 값의 오름차순으로 정렬
        db.collection("final").orderBy("start", Query.Direction.ASCENDING)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
                            Log.e("FireStore Error", error.getMessage());
                            return;
                        }

                        for (DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                sensorArrayList.add(dc.getDocument().toObject(Sensor.class));
                                date_list.add(String.valueOf(sensorArrayList.get(sensorArrayList.size()-1).getDate()));

                            }else if(dc.getType() == DocumentChange.Type.REMOVED){
                                sensorArrayList.remove(dc.getDocument().toObject(Sensor.class));
                            }else if(dc.getType() == DocumentChange.Type.MODIFIED){
                            }
                        }
                        listAdapter.notifyDataSetChanged();
                        recyclerView.scrollToPosition(sensorArrayList.size()-1); //새로운 document가 추가될 때 해당 위치로 자동 스크롤
                        recyclerView.startLayoutAnimation();

                        Log.d("Tag_",String.valueOf(dates.size()));
                        Log.d("Tag",String.valueOf(listAdapter.getItemCount()));
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();

                        for (String yeas : date_list) {
                            if (dates.contains(yeas)) {
                                dates.add("");
                            } else {
                                dates.add(yeas);
                            }
                        }


                    }
                });


    }


    }



