package com.example.date_test;

public class Sensor {

    private String mode;
    private String time_str;
    private long start;
    private long stop;
    private String date;

    public Sensor(){}

    public Sensor(String mode, long start, long stop, String date,String time_str) {
        this.mode = mode;
        this.start = start;
        this.stop = stop;
        this.date = date;
        this.time_str = time_str;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public long getStart() {
        return start;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public long getStop() {
        return stop;
    }

    public void setStop(long stop) {
        this.stop = stop;
    }

    public String getTime_str() { return time_str; }

    public void setTime_str(String time_str) { this.time_str = time_str; }
}
