package com.example.date_test;

public class Date {
    private long date;

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public Date(long date) {
        this.date = date;
    }
}
